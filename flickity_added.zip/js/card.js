$(function(){

    $('#show1').on('click',function(){        
        $('.card-reveal1').slideToggle('slow');
    });
    $('.card-reveal1 .close').on('click',function(){
        $('.card-reveal1').slideToggle('slow');
    });

    $('#show2').on('click',function(){        
        $('.card-reveal2').slideToggle('slow');
    });
    $('.card-reveal2 .close').on('click',function(){
        $('.card-reveal2').slideToggle('slow');
    });

    $('#show3').on('click',function(){        
        $('.card-reveal3').slideToggle('slow');
    });
    $('.card-reveal3 .close').on('click',function(){
        $('.card-reveal3').slideToggle('slow');
    });

    $('#show4').on('click',function(){        
        $('.card-reveal4').slideToggle('slow');
    });
    $('.card-reveal4 .close').on('click',function(){
        $('.card-reveal4').slideToggle('slow');
    });

    $('#show5').on('click',function(){        
        $('.card-reveal5').slideToggle('slow');
    });
    $('.card-reveal5 .close').on('click',function(){
        $('.card-reveal5').slideToggle('slow');
    });

    $('#show6').on('click',function(){        
        $('.card-reveal6').slideToggle('slow');
    });
    $('.card-reveal6 .close').on('click',function(){
        $('.card-reveal6').slideToggle('slow');
    });

    $('#show7').on('click',function(){        
        $('.card-reveal7').slideToggle('slow');
    });
    $('.card-reveal7 .close').on('click',function(){
        $('.card-reveal7').slideToggle('slow');
    });

    $('#show8').on('click',function(){        
        $('.card-reveal8').slideToggle('slow');
    });
    $('.card-reveal8 .close').on('click',function(){
        $('.card-reveal8').slideToggle('slow');
    });

    $('#show9').on('click',function(){        
        $('.card-reveal9').slideToggle('slow');
    });
    $('.card-reveal9 .close').on('click',function(){
        $('.card-reveal9').slideToggle('slow');
    });

    $('#show10').on('click',function(){        
        $('.card-reveal10').slideToggle('slow');
    });
    $('.card-reveal10 .close').on('click',function(){
        $('.card-reveal10').slideToggle('slow');
    });
});
$(document).ready(function(){
    $("#show1").hover(function(){
        $("#show1 .threedotshover").fadeIn("fast");
        }, function(){
        $("#show1 .threedotshover").fadeOut("fast");
    });
});
$(document).ready(function(){
    $("#show2").hover(function(){
        $("#show2 .threedotshover").fadeIn("fast");
        }, function(){
        $("#show2 .threedotshover").fadeOut("fast");
    });
});
$(document).ready(function(){
    $("#show3").hover(function(){
        $("#show3 .threedotshover").fadeIn("fast");
        }, function(){
        $("#show3 .threedotshover").fadeOut("fast");
    });
});
$(document).ready(function(){
    $("#show4").hover(function(){
        $("#show4 .threedotshover").fadeIn("fast");
        }, function(){
        $("#show4 .threedotshover").fadeOut("fast");
    });
});
$(document).ready(function(){
    $("#show5").hover(function(){
        $("#show5 .threedotshover").fadeIn("fast");
        }, function(){
        $("#show5 .threedotshover").fadeOut("fast");
    });
});
$(document).ready(function(){
    $("#show6").hover(function(){
        $("#show6 .threedotshover").fadeIn("fast");
        }, function(){
        $("#show6 .threedotshover").fadeOut("fast");
    });
});
$(document).ready(function(){
    $("#show7").hover(function(){
        $("#show7 .threedotshover").fadeIn("fast");
        }, function(){
        $("#show7 .threedotshover").fadeOut("fast");
    });
});
$(document).ready(function(){
    $("#show8").hover(function(){
        $("#show8 .threedotshover").fadeIn("fast");
        }, function(){
        $("#show8 .threedotshover").fadeOut("fast");
    });
});
$(document).ready(function(){
    $("#show9").hover(function(){
        $("#show9 .threedotshover").fadeIn("fast");
        }, function(){
        $("#show9 .threedotshover").fadeOut("fast");
    });
});
$(document).ready(function(){
    $("#show10").hover(function(){
        $("#show10 .threedotshover").fadeIn("fast");
        }, function(){
        $("#show10 .threedotshover").fadeOut("fast");
    });
});
/*
$(window).load(function () {
    $("#loader").delay(1000).fadeOut();
    $("#pre-div").delay(1500).fadeOut("slow");
});
$.each( $('*'), function() { 
    if( $(this).width() > $('body').width()) {
        console.log("Wide Element: ", $(this), "Width: ", $(this).width()); 
    } 
});
*/